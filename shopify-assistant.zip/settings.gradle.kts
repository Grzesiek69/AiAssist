rootProject.name = "shopify-assistant"
